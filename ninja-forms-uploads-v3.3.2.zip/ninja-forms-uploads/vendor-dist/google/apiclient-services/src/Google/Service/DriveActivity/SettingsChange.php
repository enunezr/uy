<?php

namespace NF_FU_VENDOR;

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
class Google_Service_DriveActivity_SettingsChange extends \NF_FU_VENDOR\Google_Collection
{
    protected $collection_key = 'restrictionChanges';
    protected $restrictionChangesType = 'Google_Service_DriveActivity_RestrictionChange';
    protected $restrictionChangesDataType = 'array';
    /**
     * @param Google_Service_DriveActivity_RestrictionChange
     */
    public function setRestrictionChanges($restrictionChanges)
    {
        $this->restrictionChanges = $restrictionChanges;
    }
    /**
     * @return Google_Service_DriveActivity_RestrictionChange
     */
    public function getRestrictionChanges()
    {
        return $this->restrictionChanges;
    }
}
