<?php

/*
 * Copyright 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
namespace NF_FU_VENDOR\Google\Auth;

use NF_FU_VENDOR\Psr\Cache\CacheItemPoolInterface;
/**
 * A class to implement caching for any object implementing
 * FetchAuthTokenInterface
 */
class FetchAuthTokenCache implements \NF_FU_VENDOR\Google\Auth\FetchAuthTokenInterface, \NF_FU_VENDOR\Google\Auth\SignBlobInterface
{
    use CacheTrait;
    /**
     * @var FetchAuthTokenInterface
     */
    private $fetcher;
    /**
     * @var array
     */
    private $cacheConfig;
    /**
     * @var CacheItemPoolInterface
     */
    private $cache;
    public function __construct(\NF_FU_VENDOR\Google\Auth\FetchAuthTokenInterface $fetcher, array $cacheConfig = null, \NF_FU_VENDOR\Psr\Cache\CacheItemPoolInterface $cache)
    {
        $this->fetcher = $fetcher;
        $this->cache = $cache;
        $this->cacheConfig = \array_merge(['lifetime' => 1500, 'prefix' => ''], (array) $cacheConfig);
    }
    /**
     * Implements FetchAuthTokenInterface#fetchAuthToken.
     *
     * Checks the cache for a valid auth token and fetches the auth tokens
     * from the supplied fetcher.
     *
     * @param callable $httpHandler callback which delivers psr7 request
     *
     * @return array the response
     *
     * @throws \Exception
     */
    public function fetchAuthToken(callable $httpHandler = null)
    {
        // Use the cached value if its available.
        //
        // TODO: correct caching; update the call to setCachedValue to set the expiry
        // to the value returned with the auth token.
        //
        // TODO: correct caching; enable the cache to be cleared.
        $cacheKey = $this->fetcher->getCacheKey();
        $cached = $this->getCachedValue($cacheKey);
        if (!empty($cached)) {
            return ['access_token' => $cached];
        }
        $auth_token = $this->fetcher->fetchAuthToken($httpHandler);
        if (isset($auth_token['access_token'])) {
            $this->setCachedValue($cacheKey, $auth_token['access_token']);
        }
        return $auth_token;
    }
    /**
     * @return string
     */
    public function getCacheKey()
    {
        return $this->getFullCacheKey($this->fetcher->getCacheKey());
    }
    /**
     * @return array|null
     */
    public function getLastReceivedToken()
    {
        return $this->fetcher->getLastReceivedToken();
    }
    /**
     * Get the client name from the fetcher.
     *
     * @param callable $httpHandler An HTTP handler to deliver PSR7 requests.
     * @return string
     */
    public function getClientName(callable $httpHandler = null)
    {
        return $this->fetcher->getClientName($httpHandler);
    }
    /**
     * Sign a blob using the fetcher.
     *
     * @param string $stringToSign The string to sign.
     * @param bool $forceOpenssl Require use of OpenSSL for local signing. Does
     *        not apply to signing done using external services. **Defaults to**
     *        `false`.
     * @return string The resulting signature.
     * @throws \RuntimeException If the fetcher does not implement
     *     `Google\Auth\SignBlobInterface`.
     */
    public function signBlob($stringToSign, $forceOpenSsl = \false)
    {
        if (!$this->fetcher instanceof \NF_FU_VENDOR\Google\Auth\SignBlobInterface) {
            throw new \RuntimeException('Credentials fetcher does not implement ' . 'Google\\Auth\\SignBlobInterface');
        }
        return $this->fetcher->signBlob($stringToSign, $forceOpenSsl);
    }
}
