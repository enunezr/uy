<?php

/*
 * Copyright 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
namespace NF_FU_VENDOR\Google\Auth\Cache;

use NF_FU_VENDOR\Psr\Cache\CacheItemInterface;
use NF_FU_VENDOR\Psr\Cache\CacheItemPoolInterface;
/**
 * Simple in-memory cache implementation.
 */
final class MemoryCacheItemPool implements \NF_FU_VENDOR\Psr\Cache\CacheItemPoolInterface
{
    /**
     * @var CacheItemInterface[]
     */
    private $items;
    /**
     * @var CacheItemInterface[]
     */
    private $deferredItems;
    /**
     * {@inheritdoc}
     */
    public function getItem($key)
    {
        return \current($this->getItems([$key]));
    }
    /**
     * {@inheritdoc}
     */
    public function getItems(array $keys = [])
    {
        $items = [];
        foreach ($keys as $key) {
            $items[$key] = $this->hasItem($key) ? clone $this->items[$key] : new \NF_FU_VENDOR\Google\Auth\Cache\Item($key);
        }
        return $items;
    }
    /**
     * {@inheritdoc}
     */
    public function hasItem($key)
    {
        $this->isValidKey($key);
        return isset($this->items[$key]) && $this->items[$key]->isHit();
    }
    /**
     * {@inheritdoc}
     */
    public function clear()
    {
        $this->items = [];
        $this->deferredItems = [];
        return \true;
    }
    /**
     * {@inheritdoc}
     */
    public function deleteItem($key)
    {
        return $this->deleteItems([$key]);
    }
    /**
     * {@inheritdoc}
     */
    public function deleteItems(array $keys)
    {
        \array_walk($keys, [$this, 'isValidKey']);
        foreach ($keys as $key) {
            unset($this->items[$key]);
        }
        return \true;
    }
    /**
     * {@inheritdoc}
     */
    public function save(\NF_FU_VENDOR\Psr\Cache\CacheItemInterface $item)
    {
        $this->items[$item->getKey()] = $item;
        return \true;
    }
    /**
     * {@inheritdoc}
     */
    public function saveDeferred(\NF_FU_VENDOR\Psr\Cache\CacheItemInterface $item)
    {
        $this->deferredItems[$item->getKey()] = $item;
        return \true;
    }
    /**
     * {@inheritdoc}
     */
    public function commit()
    {
        foreach ($this->deferredItems as $item) {
            $this->save($item);
        }
        $this->deferredItems = [];
        return \true;
    }
    /**
     * Determines if the provided key is valid.
     *
     * @param string $key
     * @return bool
     * @throws InvalidArgumentException
     */
    private function isValidKey($key)
    {
        $invalidCharacters = '{}()/\\\\@:';
        if (!\is_string($key) || \preg_match("#[{$invalidCharacters}]#", $key)) {
            throw new \NF_FU_VENDOR\Google\Auth\Cache\InvalidArgumentException('The provided key is not valid: ' . \var_export($key, \true));
        }
        return \true;
    }
}
